create procedure pruebaprro(var integer, vari integer, INOUT resp integer)
    language plpgsql
as
$$
DECLARE
BEGIN


resp := var + vari;


END;
$$;

alter procedure pruebaprro(integer, integer, inout integer) owner to postgres;

