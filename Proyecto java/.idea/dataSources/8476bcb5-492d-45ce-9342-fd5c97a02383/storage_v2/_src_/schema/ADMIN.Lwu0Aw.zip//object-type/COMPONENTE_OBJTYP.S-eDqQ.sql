create TYPE Componente_objtyp UNDER Parte_objtyp(
    ListaItems arrayItems,
    ListaCantidades arrayCantidades,
    MEMBER FUNCTION contarComponentes RETURN INTEGER,
    MEMBER FUNCTION contarPartes RETURN INTEGER
);
/

