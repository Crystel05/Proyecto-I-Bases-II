create PROCEDURE revisarFinSubastas(resultado OUT INTEGER)
 IS
    
    cantFilas INTEGER;
    i INTEGER;
    fechaFila TIMESTAMP(9);
 BEGIN

    SELECT COUNT(ID) INTO cantFilas FROM subasta;
    FOR i IN 1 ..(cantFilas) LOOP
        SELECT fechaFinal INTO fechaFila FROM subasta WHERE ID = i;
        IF CURRENT_TIMESTAMP > fechaFila THEN
            UPDATE subasta 
            SET activo = 0
            WHERE ID = i;
        END IF;
    END LOOP;

 END;
/

