create trigger CUSTOMERS_AUDIT_TRG
    before insert
    on PUJA
    for each row
DECLARE
   montoViejo VARCHAR2(10);
   ultimaPuja INTEGER;
BEGIN

    SELECT MAX(monto) INTO montoViejo
    FROM puja 
    WHERE subastaid = :new.subastaID;

    IF montoViejo < :new.monto  OR montoViejo IS NULL THEN
        UPDATE subasta 
        SET montoactual = :new.monto
        WHERE ID = :new.subastaID;
    ELSE
        UPDATE subasta 
        SET montoactual = montoViejo
        WHERE ID = :new.subastaID;
    END IF;
END;
/

