create PROCEDURE mostrarIdentidad(esAdmin IN INTEGER, cursor OUT SYS_REFCURSOR)
IS

BEGIN

    IF esAdmin = 1 THEN
        OPEN CURSOR FOR 
        SELECT 
        docIdentidad, nombreapellidos
        FROM usuario
        WHERE ID IN (SELECt usuarioID FROM administrador);
    ELSE
        OPEN CURSOR FOR 
        SELECT 
        docIdentidad, nombreapellidos
        FROM usuario
        WHERE ID IN (SELECt usuarioID FROM participante);
    END IF;
END ;
/

