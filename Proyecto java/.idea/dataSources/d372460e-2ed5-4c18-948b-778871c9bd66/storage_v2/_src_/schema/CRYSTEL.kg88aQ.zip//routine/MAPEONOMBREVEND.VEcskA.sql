create PROCEDURE mapeoNombreVend(nomItem varchar, cursor OUT SYS_REFCURSOR)
IS
	
	
BEGIN

    OPEN CURSOR FOR
    SELECT DISTINCT nombreapellidos 
    FROM SUBASTA     
    INNER JOIN ITEM ON subasta.itemid = ITEM.ID AND ITEM.NOMBRE = nomItem
    INNER JOIN VENDEDOR ON subasta.vendedorid = VENDEDOR.ID
    INNER JOIN PARTICIPANTE ON vendedor.participanteid = PARTICIPANTE.ID
    INNER JOIN USUARIO ON participante.usuarioid = USUARIO.ID;


END;
/

