create TYPE Parte AS OBJECT(
    
    Codigo VARCHAR(3),
    Nombre VARCHAR(100)
)NOT FINAL;
/

