create PROCEDURE comprasXcomprador(ident varchar, cursor OUT SYS_REFCURSOR)
IS
	
	
BEGIN

            OPEN cursor FOR
			SELECT item.nombre, subasta.precioinicial, puja.monto, 
            puja.fechaHora, comentario.comentario, comentario.puntaje, 
            item.descripcion, subasta.detallesentrega, item.imagen
            FROM historialcomprador
            INNER JOIN subasta ON historialcomprador.subastaid = subasta.ID
            INNER JOIN comentario ON comentario.subastaid = subasta.ID AND comentario.esVendedor = 1
            INNER JOIN item ON subasta.itemid = item.ID
            INNER JOIN puja ON subasta.montoActual = puja.monto AND puja.subastaid = subasta.ID
            INNER JOIN comprador ON historialcomprador.compradorId = comprador.ID
            INNER JOIN participante ON comprador.participanteID = participante.ID
            INNER JOIN usuario ON participante.usuarioId = usuario.ID AND usuario.docidentidad = ident; 

END;
/

