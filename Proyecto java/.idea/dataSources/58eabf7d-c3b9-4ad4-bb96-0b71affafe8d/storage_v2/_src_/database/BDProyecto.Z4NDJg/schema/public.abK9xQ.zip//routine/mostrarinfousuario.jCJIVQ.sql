create function mostrarinfousuario(ced character varying)
    returns TABLE(contra character varying, nombre character varying, cedula character varying, dir character varying, alis character varying)
    language plpgsql
as
$$
BEGIN
	
	RETURN QUERY
	SELECT contrasenna, nombreapellidos, docIdent, direccion, "Alias"
	FROM usuario
	WHERE docIdent = ced;

END;
$$;

alter function mostrarinfousuario(varchar) owner to postgres;

