create function mostcategorias()
    returns TABLE(nombre character varying)
    language plpgsql
as
$$
DECLARE
BEGIN
	
	RETURN QUERY
	SELECT categoria.nombre FROM categoria;

END;
$$;

alter function mostcategorias() owner to postgres;

