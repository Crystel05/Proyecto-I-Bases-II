create function mostrarsubastascompradornot(ali character varying, contra character varying)
    returns TABLE(nombreitem character varying, descripcionitem character varying, fotoi character varying, detallesentregas character varying)
    language plpgsql
as
$$
DECLARE 
	compId int;
BEGIN
	
	compId := (SELECT comprador."ID" 
			   FROM comprador
			   INNER JOIN participante ON comprador."participanteId" = participante."ID"
			   INNER JOIN usuario ON participante."usuarioId" = usuario."ID" 
			   AND usuario."Alias" = ali AND usuario.contrasenna = contra);

	RETURN QUERY
	SELECT item.nombre, item.descripcion, item.foto, subasta.detallesentrega
	FROM subasta 
	INNER JOIN item ON item."ID" = subasta.itemid
	INNER JOIN puja ON puja.oferta = subasta."mejorMonto" AND puja."subastaId" = subasta."ID"
	INNER JOIN comprador ON puja."compradorId" = comprador."ID" AND comprador."ID" = compId
	WHERE subasta.activa = FALSE;
		
END;
$$;

alter function mostrarsubastascompradornot(varchar, varchar) owner to postgres;

