create function nombrevendedor(dociden character varying) returns character varying
    language plpgsql
as
$$
DECLARE 
		nombreApVend varchar;
BEGIN
		nombreApVend := (SELECT nombreapellidos FROM usuario WHERE docident = docIden);
		RETURN nombreApVend;

END;
$$;

alter function nombrevendedor(varchar) owner to postgres;

