create function mostrarusuarios()
    returns TABLE(cedula character varying, nombre character varying)
    language plpgsql
as
$$
BEGIN
	
	RETURN QUERY
	SELECT usuario.docident, usuario.nombreapellidos
	FROM participante 
	INNER JOIN usuario ON participante."usuarioId" = usuario."ID";

END;
$$;

alter function mostrarusuarios() owner to postgres;

