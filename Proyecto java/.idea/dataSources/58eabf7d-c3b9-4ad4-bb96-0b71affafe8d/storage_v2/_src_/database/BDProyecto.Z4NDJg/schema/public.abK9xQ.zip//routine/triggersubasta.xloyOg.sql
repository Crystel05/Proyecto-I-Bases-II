create function triggersubasta() returns trigger
    language plpgsql
as
$$
DECLARE
	montoViejo DECIMAL(19,4);

BEGIN

	SELECT MAX(oferta) INTO montoViejo
    FROM puja 
    WHERE "subastaId" = NEW."subastaId";

    IF montoViejo < NEW.oferta OR montoViejo IS NULL THEN
        UPDATE subasta 
        SET "mejorMonto" = NEW.oferta
        WHERE "ID" = NEW."subastaId";
    ELSE
        UPDATE subasta 
        SET "mejorMonto" = montoViejo
        WHERE "ID" = NEW."subastaId";
    END IF;
	RETURN NEW;

END;
$$;

alter function triggersubasta() owner to postgres;

