create function mostrartipostel()
    returns TABLE(nombre character varying)
    language plpgsql
as
$$
BEGIN
	
	RETURN QUERY
	SELECT tipotelefono.nombre FROM tipotelefono;

END;
$$;

alter function mostrartipostel() owner to postgres;

