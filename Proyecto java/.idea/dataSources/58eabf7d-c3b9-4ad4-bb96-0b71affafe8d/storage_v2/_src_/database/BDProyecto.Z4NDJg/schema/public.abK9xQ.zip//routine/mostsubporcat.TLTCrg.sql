create function mostsubporcat(categ character varying)
    returns TABLE(nombreit character varying, fechafin timestamp without time zone, monto numeric)
    language plpgsql
as
$$
BEGIN
	
	RETURN QUERY
	SELECT  item.nombre, fechafinal, "mejorMonto"
    FROM subasta
    INNER JOIN item ON subasta.itemid = item."ID"
	INNER JOIN subcategoria ON item."subcategoriaId" = subcategoria."ID"
	INNER JOIN categoria ON subcategoria."categoriaId" = categoria."ID" 
	WHERE categoria."nombre" = categ AND activa = TRUE;

END;
$$;

alter function mostsubporcat(varchar) owner to postgres;

