create function mostrarsubastasvendedornot(ali character varying, contra character varying)
    returns TABLE(nombreitem character varying, descripcionitem character varying, fotoi character varying, detallesentregas character varying)
    language plpgsql
as
$$
DECLARE 
	vendid int;
BEGIN
	
	vendid := (SELECT vendedor."ID" 
			   FROM vendedor
			   INNER JOIN participante ON vendedor."participanteId" =participante."ID"
			   INNER JOIN usuario ON participante."usuarioId" = usuario."ID" 
			   AND usuario."Alias" = ali AND usuario.contrasenna = contra);

	RETURN QUERY
	SELECT item.nombre, item.descripcion, item.foto, subasta.detallesentrega
	FROM subasta 
	INNER JOIN item ON item."ID" = subasta.itemid
	WHERE subasta.vendedorid = vendid AND subasta.activa = FALSE;
		
END;
$$;

alter function mostrarsubastasvendedornot(varchar, varchar) owner to postgres;

