create function pruebacal() returns integer
    language plpgsql
as
$$
DECLARE

 linea RECORD;

BEGIN
	
	FOR linea IN SELECT * FROM subasta
	LOOP
		IF (SELECT NOW()) > linea.fechafinal
		THEN
		   UPDATE subasta 
		   SET activa = false
		   WHERE "ID" = linea."ID";
		END IF;
	END LOOP; 
	RETURN 1;

END;
$$;

alter function pruebacal() owner to postgres;

