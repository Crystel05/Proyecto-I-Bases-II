create function pujasxsubasta(nombreitem character varying)
    returns TABLE(cantidadpuja numeric, fecha timestamp without time zone)
    language plpgsql
as
$$
BEGIN
	
	RETURN QUERY
	SELECT puja.oferta, puja."fechaHora" 
	FROM puja
	INNER JOIN subasta ON puja."subastaId" = subasta."ID"
	INNER JOIN item ON subasta.itemid = Item."ID" WHERE item."nombre" = nombreItem;
END;
$$;

alter function pujasxsubasta(varchar) owner to postgres;

