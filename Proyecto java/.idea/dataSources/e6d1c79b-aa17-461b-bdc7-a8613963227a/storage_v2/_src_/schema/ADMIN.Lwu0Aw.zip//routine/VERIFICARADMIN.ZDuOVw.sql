create PROCEDURE verificarAdmin(aliass IN varchar2, cursor OUT SYS_REFCURSOR)
IS

   -- numUsuario INTEGER;

BEGIN

    --SELECT ID INTO numUsuario FROM usuario WHERE alias = aliass;

    OPEN cursor FOR SELECT contrasenna FROM administrador;

END;
/

