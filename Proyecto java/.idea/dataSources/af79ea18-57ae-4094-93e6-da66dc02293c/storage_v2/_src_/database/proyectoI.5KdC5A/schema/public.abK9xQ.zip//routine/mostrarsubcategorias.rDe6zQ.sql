create function mostrarsubcategorias(categorianom character varying)
    returns TABLE(nombre character varying)
    language plpgsql
as
$$
DECLARE
BEGIN
	
	RETURN QUERY
	SELECT subcategoria.nombre
    FROM subcategoria INNER JOIN categoria
    ON categoria."ID" = subcategoria."categoriaId"
    WHERE categoria.nombre = categoriaNom;

END;
$$;

alter function mostrarsubcategorias(varchar) owner to postgres;

