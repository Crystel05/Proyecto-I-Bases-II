create function verificariniciosesion(esadmin boolean, alias character varying, contra character varying) returns integer
    language plpgsql
as
$$
DECLARE
	usuarioID int;
	tipoID int;
BEGIN
	usuarioID := (SELECT "ID" FROM usuario WHERE "Alias" = "alias" and contrasenna = contra); 
	IF usuarioID IS NOT NULL
	THEN 
		IF esAdmin
		THEN
			tipoID := (SELECT "ID" FROM administrador WHERE administrador."usuarioId"= usuarioID);
		ELSE
			tipoID := (SELECT "ID" FROM participante WHERE participante."usuarioId" = usuarioID);
		END IF;
		IF tipoID IS NOT NULL
		THEN 
			RETURN 1;
		ELSE
			RETURN 0;
		END IF;
	ELSE
		RETURN 0;
	END IF;

END;
$$;

alter function verificariniciosesion(boolean, varchar, varchar) owner to postgres;

