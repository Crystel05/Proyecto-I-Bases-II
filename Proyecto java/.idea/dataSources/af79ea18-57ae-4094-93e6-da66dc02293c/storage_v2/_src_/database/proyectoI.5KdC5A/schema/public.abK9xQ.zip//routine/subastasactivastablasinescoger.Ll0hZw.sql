create function subastasactivastablasinescoger()
    returns TABLE(nombreitem character varying, fechafinals timestamp without time zone, monto numeric)
    language plpgsql
as
$$
DECLARE
BEGIN
	
	RETURN QUERY
	SELECT  nombre, fechafinal, "mejorMonto"
    FROM subasta
    INNER JOIN item on subasta.itemid = item."ID"
    WHERE activa = TRUE;

END;
$$;

alter function subastasactivastablasinescoger() owner to postgres;

