create function mostsubporsubcat(subcategori character varying)
    returns TABLE(nombreit character varying, fechafin timestamp without time zone, monto numeric)
    language plpgsql
as
$$
DECLARE 
	subcatId int;
	
BEGIN

	subcatId := (SELECT "ID" FROM public.subcategoria WHERE nombre = subcategori);

	RETURN QUERY
	SELECT  item.nombre, fechafinal, "mejorMonto"
    FROM subasta
    INNER JOIN item on subasta.itemid = item."ID"
    WHERE item."subcategoriaId" = subcatId AND activa = TRUE; 

END;
$$;

alter function mostsubporsubcat(varchar) owner to postgres;

