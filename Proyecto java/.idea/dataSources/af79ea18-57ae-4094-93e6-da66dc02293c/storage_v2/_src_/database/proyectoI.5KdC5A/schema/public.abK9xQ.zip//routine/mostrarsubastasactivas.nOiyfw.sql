create function mostrarsubastasactivas()
    returns TABLE(nombreitem character varying, fechafinal timestamp without time zone, monto money)
    language plpgsql
as
$$
BEGIN

--	RETURN QUERY
--	SELECT "ID" FROM subasta WHERE activa = true;
	
	RETURN QUERY
	SELECT nombre, subasta.fechaFinal, oferta
	FROM subasta
	INNER JOIN item on subasta.itemid = item."ID"
	INNER JOIN puja on "mejorPujaActualId" = puja."ID"
	WHERE subasta.activa = TRUE;

END;
$$;

alter function mostrarsubastasactivas() owner to postgres;

