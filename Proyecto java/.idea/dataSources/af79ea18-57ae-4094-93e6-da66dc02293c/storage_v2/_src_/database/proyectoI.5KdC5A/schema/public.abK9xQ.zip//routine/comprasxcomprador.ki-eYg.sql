create function comprasxcomprador(ident character varying)
    returns TABLE(itemnombre character varying, preciobase numeric, preciofinal numeric, fecha timestamp without time zone)
    language plpgsql
as
$$
BEGIN
	
		RETURN QUERY
		SELECT item.nombre, subasta.precioinicial, puja.oferta, puja."fechaHora"
		FROM historialcomprador
		INNER JOIN subasta ON historialcomprador.subastaid = subasta."ID"
		INNER JOIN item ON subasta.itemid = item."ID"
		INNER JOIN puja ON subasta."mejorMonto" = puja.oferta
		INNER JOIN participante ON historialcomprador."compradorId" = participante."ID"
		INNER JOIN usuario ON participante."usuarioId" = usuario."ID"
		AND usuario.docident = ident;
		
END;
$$;

alter function comprasxcomprador(varchar) owner to postgres;

