create function modificartelefono(numviejo integer, numnuevo integer, tipotel character varying) returns integer
    language plpgsql
as
$$
DECLARE

	tipoID integer;
	telID integer;

BEGIN
	
	tipoID := (SELECT "ID" FROM tipotelefono WHERE nombre = tipotel);
	telID := (SELECT "ID" FROM telefono WHERE telefono = numViejo);

	UPDATE telefono
    SET telefono = numNuevo,
    tipotelefonoid = tipoID
    WHERE "ID" = telID;
	
	RETURN 1;

END;
$$;

alter function modificartelefono(integer, integer, varchar) owner to postgres;

