create function mostrartodassubastas()
    returns TABLE(nombre character varying)
    language plpgsql
as
$$
BEGIN
	
	RETURN QUERY
	SELECT item.nombre FROM item
	INNER JOIN subasta on itemid = item."ID";

END;
$$;

alter function mostrartodassubastas() owner to postgres;

