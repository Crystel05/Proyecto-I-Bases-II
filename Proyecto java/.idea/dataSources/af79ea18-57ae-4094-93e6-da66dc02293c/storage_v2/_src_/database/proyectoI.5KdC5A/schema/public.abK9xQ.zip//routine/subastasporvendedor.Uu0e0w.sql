create function subastasporvendedor(dociden character varying)
    returns TABLE(coment character varying, punt integer, nombreitem character varying, fecha timestamp without time zone, precioinicial numeric, preciofinal numeric, nombreganador character varying)
    language plpgsql
as
$$
DECLARE 
		UsuarioId integer;
		compradorId integer;

BEGIN

		UsuarioId := (SELECT vendedor."ID"
		FROM subasta
		INNER JOIN vendedor ON subasta.vendedorid = vendedor."ID"
		INNER JOIN participante ON vendedor."participanteId"= participante."ID"
		INNER JOIN usuario ON participante."usuarioId" = usuario."ID"
		WHERE usuario.docident = docIden);
	
		
		RETURN QUERY
		SELECT comentarios.comentario, comentarios.puntuacion, item.nombre, fechafinal, 
		subasta.precioinicial, subasta."mejorMonto", nombreapellidos
		FROM subasta
		INNER JOIN comentarios ON comentarios.subastaid = subasta."ID" AND comentarios."esVendedor" = FALSE
		INNER JOIN item ON subasta.itemid = item."ID"
		INNER JOIN comprador ON comentarios.compradorid = comprador."ID"
		INNER JOIN participante ON comprador."participanteId" = participante."ID"
		INNER JOIN usuario ON participante."usuarioId" = usuario."ID"
		WHERE subasta.activa = FALSE AND subasta.vendedorid = UsuarioId ;

END;
$$;

alter function subastasporvendedor(varchar) owner to postgres;

