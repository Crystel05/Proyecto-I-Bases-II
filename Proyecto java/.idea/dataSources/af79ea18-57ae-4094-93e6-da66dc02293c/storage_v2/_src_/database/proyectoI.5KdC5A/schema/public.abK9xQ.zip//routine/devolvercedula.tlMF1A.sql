create function devolvercedula(alis character varying, contra character varying) returns character varying
    language plpgsql
as
$$
DECLARE 
	docidentidad integer;

BEGIN

	docidentidad := (SELECT docident FROM usuario WHERE "Alias" = alis AND contrasenna = contra);
	
	RETURN docidentidad;
	
END;
$$;

alter function devolvercedula(varchar, varchar) owner to postgres;

