create function modificarusuario(cedvieja character varying, nomap character varying, alinuevo character varying, contra character varying, cedula character varying, direcc character varying) returns integer
    language plpgsql
as
$$
DECLARE
BEGIN
	IF cedVieja = cedula
	THEN
		UPDATE usuario
		SET "Alias" = aliNuevo,
		nombreapellidos = nomAp,
		docident = cedula,
		direccion = direcc,
		contrasenna = contra
		WHERE docident = cedVieja;
		RETURN 1;
	ELSE
		IF (SELECT "ID" FROM usuario WHERE docident = cedula) IS NULL
		THEN
			
			UPDATE usuario
			SET "Alias" = aliNuevo,
			nombreapellidos = nomAp,
			docident = cedula,
			direccion = direcc,
			contrasenna = contra
			WHERE docident = cedVieja;
			RETURN 1;
		ELSE
			RETURN 0;
		END IF;
	END IF;

END;
$$;

alter function modificarusuario(varchar, varchar, varchar, varchar, varchar, varchar) owner to postgres;

