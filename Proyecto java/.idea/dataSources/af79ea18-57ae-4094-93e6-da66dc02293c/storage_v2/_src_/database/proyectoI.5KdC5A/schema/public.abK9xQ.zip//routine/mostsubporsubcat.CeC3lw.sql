create function mostsubporsubcat(categori character varying, subcategori character varying)
    returns TABLE(subastaid integer, nombreit character varying, fechafin timestamp without time zone, monto numeric)
    language plpgsql
as
$$
DECLARE 
	subcatId int;
	dato RECORD;
	
BEGIN

	subcatId := (SELECT subcategoria."ID" FROM public.subcategoria 
	INNER JOIN categoria ON subcategoria."categoriaId" = categoria."ID"
	WHERE subcategoria.nombre = subcategori AND categoria.nombre = categori);

	FOR dato IN 
		SELECT subasta."ID" as subast, item.nombre as itemNom, fechafinal, "mejorMonto", precioinicial
		FROM subasta
		INNER JOIN item on subasta.itemid = item."ID"
		WHERE item."subcategoriaId" = subcatId AND activa = TRUE LOOP
		
		subastaID := dato.subast;
		nombreIt := dato.itemNom;
		fechaFin := dato.fechafinal;
		
		IF dato."mejorMonto" = 0
		THEN 
		
			monto := dato.precioinicial;
			
		ELSE
		
			monto := dato."mejorMonto";
		
		END IF;
		
		RETURN NEXT;
	END LOOP;

END;
$$;

alter function mostsubporsubcat(varchar, varchar) owner to postgres;

