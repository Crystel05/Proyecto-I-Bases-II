create function mostsubporcat(categ character varying)
    returns TABLE(subid integer, nombreit character varying, fechafin timestamp without time zone, monto numeric)
    language plpgsql
as
$$
DECLARE 
	dato RECORD;

BEGIN
	
	FOR dato IN
		SELECT subasta."ID" as "subastaI", item.nombre as itemNombre, fechafinal, "mejorMonto", precioinicial
		FROM subasta
		INNER JOIN item ON subasta.itemid = item."ID"
		INNER JOIN subcategoria ON item."subcategoriaId" = subcategoria."ID"
		INNER JOIN categoria ON subcategoria."categoriaId" = categoria."ID" AND categoria."nombre" = categ
		WHERE subasta.activa = TRUE LOOP
		
		subId := dato."subastaI";
		nombreIt := dato.itemNombre;
		fechaFin := dato.fechafinal;
		
		IF dato."mejorMonto" = 0
		THEN 
			
			monto := dato.precioinicial;
			
		ELSE
		
			monto := dato."mejorMonto";
		
		END IF;
		
		RETURN NEXT;
	END LOOP;

END;
$$;

alter function mostsubporcat(varchar) owner to postgres;

