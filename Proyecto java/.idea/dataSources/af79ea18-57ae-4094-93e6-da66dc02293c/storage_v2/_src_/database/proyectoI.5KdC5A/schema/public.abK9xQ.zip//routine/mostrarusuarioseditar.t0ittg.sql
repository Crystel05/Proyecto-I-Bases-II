create function mostrarusuarioseditar(esadmin boolean)
    returns TABLE(cedula character varying, nombre character varying)
    language plpgsql
as
$$
BEGIN
	
	IF(esAdmin)
	THEN
	
		RETURN QUERY
		SELECT usuario.docident, usuario.nombreapellidos
		FROM administrador 
		INNER JOIN usuario ON administrador."usuarioId" = usuario."ID";
		
	ELSE
		
		RETURN QUERY
		SELECT usuario.docident, usuario.nombreapellidos
		FROM participante 
		INNER JOIN usuario ON participante."usuarioId" = usuario."ID";
	
	END IF;
	

END;
$$;

alter function mostrarusuarioseditar(boolean) owner to postgres;

