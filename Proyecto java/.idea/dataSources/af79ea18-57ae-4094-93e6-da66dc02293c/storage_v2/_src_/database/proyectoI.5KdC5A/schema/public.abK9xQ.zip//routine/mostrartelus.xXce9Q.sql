create function mostrartelus(cedula character varying)
    returns TABLE(numer integer)
    language plpgsql
as
$$
DECLARE
usuId int;

BEGIN
	
	usuId := (SELECT "ID" 
	FROM usuario WHERE
    docident = cedula);

   	RETURN QUERY
    SELECT telefono
    FROM telefono
    WHERE "UsuarioId" = usuId;

END;
$$;

alter function mostrartelus(varchar) owner to postgres;

