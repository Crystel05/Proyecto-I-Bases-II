create function agregartelefono(alias character varying, contra character varying, numero integer, tipo character varying) returns integer
    language plpgsql
as
$$
DECLARE
	usuarioID int;
	tipoID int;
BEGIN
	
	usuarioID := (SELECT "ID" FROM usuario WHERE "Alias" = "alias" and contrasenna = contra);
	tipoID := (SELECT "ID" FROM tipotelefono WHERE nombre = tipo);
	
	INSERT INTO telefono(telefono, tipotelefonoid, "UsuarioId")
	VALUES(numero, tipoID, usuarioID);
	
	IF (SELECT "ID" FROM telefono WHERE telefono = numero) IS NOT NULL
	THEN
		RETURN 1;
	ELSE
		RETURN 0;
	END IF;

END;
$$;

alter function agregartelefono(varchar, varchar, integer, varchar) owner to postgres;

