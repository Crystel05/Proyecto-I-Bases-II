create type           "SYS_YOID0000074036$"              as object( "CODIGO" VARCHAR2(3 BYTE))
/

