create TYPE BODY COMPONENTE AS

    MEMBER FUNCTION cantidadTotalOriginales RETURN INTEGER IS
    total integer := 0;

    BEGIN

        FOR i IN 1 .. SELF.partesComponente.COUNT LOOP
            total := total + SELF.cantidadesComponente(i);
        END LOOP;
        RETURN total;
    END;

    MEMBER FUNCTION cantidadPartesBasicas RETURN INTEGER IS
    total integer := 0;
    totalPartes integer := 0;
    BEGIN
        FOR i IN 1 .. SELF.partesComponente.COUNT LOOP

            IF (SELF.partesComponente(i).codigo = 'pan' OR SELF.partesComponente(i).codigo = 'te' OR SELF.partesComponente(i).codigo = 'cub') THEN
                SELECT c.cantidadPartesBasicas() INTO totalPartes 
                FROM componentestabla c
                WHERE codigo = SELF.partesComponente(i).codigo;
                totalPartes := totalPartes * SELF.cantidadesComponente(i);
                total := total + totalPartes;
            ELSE

                total := total + SELF.cantidadesComponente(i);

            END IF;

        END LOOP;
        RETURN total;

    END;

 END;
/

