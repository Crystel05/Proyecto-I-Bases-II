create PROCEDURE mostSubPorCat(categoria IN varchar2, cursor OUT SYS_REFCURSOR)
IS

    catId INTEGER;

BEGIN

    SELECT ID INTO catId FROM categoria WHERE nombre = categoria;

    OPEN cursor FOR SELECT  nombre, fechafinal, monto
    FROM subasta
    INNER JOIN item on subasta.itemid = item.id
    INNER JOIN puja on subasta.mejorpujaId = puja.id
    WHERE item.subcategoriaid IN 
    (SELECT ID FROM subCategoria WHERE categoriaId = catId) ; 

END;
/

