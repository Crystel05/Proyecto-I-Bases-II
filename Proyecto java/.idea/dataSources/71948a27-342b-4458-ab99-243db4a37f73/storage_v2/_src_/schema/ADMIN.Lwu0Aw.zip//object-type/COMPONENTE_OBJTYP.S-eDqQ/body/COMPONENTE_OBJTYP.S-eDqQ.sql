create TYPE BODY Componente_objtyp
AS
MEMBER FUNCTION contarComponentes RETURN INTEGER
IS
    numPiezas INTEGER := 0;
    I INTEGER;

BEGIN

    FOR i IN 1 .. SELF.ListaCantidades.COUNT LOOP
        numPiezas := numPiezas + SELF.ListaCantidades(i);
    END LOOP;

    RETURN numPiezas;

END;

MEMBER FUNCTION contarPartes RETURN INTEGER
IS

    I INTEGER;  
    partesActual INTEGER;
    tipoObj INTEGER := 3;
    Total INTEGER := 0;

BEGIN

    FOR i IN 1 .. SELF.ListaItems.COUNT LOOP

        --tipoObj := SELF.tipo;
        --UTL_REF.SELECT_OBJECT(ListaItems(i).tipo, tipoObj);

        IF ListaItems(i).tipo = 0 THEN
            Total := Total + SELF.ListaCantidades(i);

        ELSIF ListaItems(i).tipo = 1 THEN

            SELECT p.contarPartes() 
            INTO partesActual 
            FROM tablacomponentes p 
            WHERE codigo = SELF.ListaItems(i).codigo;
            Total := Total + (partesActual * (SELF.ListaCantidades(i)));

        END IF;

        /*
        UTL_REF.SELECT_OBJECT(ListaItems(i), Item);
        tipoObj := SELF.tipo;
        IF tipoObj = 0 THEN

            Total := Total + 5; --SELF.ListaCantidades(i);

        ELSE
            SELECT p.contarPartes() 
            INTO partesActual 
            FROM tablacomponentes p 
            WHERE codigo = SELF.ListaItems(i).codigo;

            Total := Total + 1;--( contarPartes * (SELF.ListaCantidades(i)));

        END IF;       
            */
    END LOOP;

    RETURN Total;

END;
END;
/

