create TYPE BODY Componente_objtyp
AS
MEMBER FUNCTION contarComponentes RETURN INTEGER
IS
    numPiezas INTEGER := 0;
    I INTEGER;

BEGIN

    FOR i IN 1 .. SELF.ListaItems.COUNT LOOP
        numPiezas := numPiezas + SELF.ListaItems(i).Cantidad;
    END LOOP;

    RETURN numPiezas;

END;

MEMBER FUNCTION contarPartes RETURN INTEGER
IS

    I INTEGER;  
    Item  Parte_objtyp;
    tipoObj varchar2(100);
    Total INTEGER := 0;

BEGIN

    FOR i IN 1 .. SELF.ListaItems.COUNT LOOP
        UTL_REF.SELECT_OBJECT(ListaItems(i).Parte_ref, Item);
        tipoObj := sys.anydata.gettypename(sys.anydata.convertobject(Item));
        IF tipoObj = 'BDTAR2.PARTE_OBJTYP' THEN

            Total := Total + SELF.ListaItems(i).Cantidad;

        ELSE

            Total := Total + (TREAT(ITEM AS Componente_objtyp).contarComponentes * SELF.ListaItems(i).Cantidad);

        END IF;

    END LOOP;

    RETURN Total;

END;
END;
/

