create TYPE LineaItems_objtyp AS OBJECT(
    Parte_ref REF Parte_objtyp,
    Cantidad INTEGER
    );
/

