create TYPE Parte_objtyp AS OBJECT(
    codigo VARCHAR2(10),
    nombre VARCHAR2(30)
    )NOT FINAL;
/

