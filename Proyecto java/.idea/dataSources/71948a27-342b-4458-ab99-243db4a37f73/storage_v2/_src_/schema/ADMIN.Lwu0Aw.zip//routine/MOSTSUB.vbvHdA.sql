create PROCEDURE mostSub(cursor OUT SYS_REFCURSOR)
IS

BEGIN

    OPEN CURSOR FOR
    SELECT  nombre, fechafinal, monto
    FROM subasta
    INNER JOIN item on subasta.itemid = item.id
    INNER JOIN puja on subasta.mejorpujaId = puja.id;

END;
/

