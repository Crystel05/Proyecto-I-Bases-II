create PROCEDURE mostrarAlias(cursor OUT SYS_REFCURSOR)
IS

BEGIN

    OPEN CURSOR FOR 
    SELECT 
    Alias
    FROM usuario;

END ;
/

