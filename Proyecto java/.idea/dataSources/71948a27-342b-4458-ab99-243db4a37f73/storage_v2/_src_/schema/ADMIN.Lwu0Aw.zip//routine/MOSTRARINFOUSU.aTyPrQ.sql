create PROCEDURE mostrarInfoUsu (aliass IN varchar2, cursor  OUT SYS_REFCURSOR)
IS

BEGIN

OPEN CURSOR FOR 
SELECT 
contrasenna,
nombreapellidos,
docIdentidad,
direccion,
alias
FROM usuario
WHERE alias = aliass;

END ;
/

