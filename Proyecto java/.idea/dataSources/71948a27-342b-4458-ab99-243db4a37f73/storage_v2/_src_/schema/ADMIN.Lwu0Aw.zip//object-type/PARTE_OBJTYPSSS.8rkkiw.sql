create TYPE Parte_objtypsss AS OBJECT(
    codigo VARCHAR2(10),
    nombre VARCHAR2(30)
    )NOT FINAL;
/

