create TYPE Componente_objtyp UNDER Parte_objtyp(
    ListaItems ListaItems_ntabtyp,
    MEMBER FUNCTION contarComponentes RETURN INTEGER,
    MEMBER FUNCTION contarPartes RETURN INTEGER
);
/

