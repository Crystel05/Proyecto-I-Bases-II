create PROCEDURE mostDetSub(sub IN INTEGER, cursor OUT SYS_REFCURSOR)
IS

    pujaId integer;

BEGIN

    SELECT ID INTO pujaId
    FROM PUJA 
    WHERE subastaid = sub;

    IF pujaId IS NOT NULL
    THEN 
        OPEN cursor FOR
        SELECT
        subasta.montoActual, 
        item.descripcion, 
        item.imagen,
        usuario.nombreapellidos
        FROM subasta
        INNER JOIN item on subasta.itemid = item.ID
        INNER JOIN puja on puja.subastaid = subasta.ID
        INNER JOIN comprador on puja.compradorId = comprador.ID
        INNER JOIN participante on participante.ID = comprador.participanteid
        INNER JOIN usuario on usuario.ID =  participante.usuarioID
        WHERE subasta.ID = sub;
    ELSE 
        OPEN cursor FOR
        SELECT
        subasta.precioinicial, 
        item.descripcion, 
        item.imagen, 
        'sin pujas'
        FROM subasta
        INNER JOIN item on subasta.itemid = item.ID
        WHERE subasta.ID = sub;
    END IF;

END;
/

