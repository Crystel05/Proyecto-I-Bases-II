create PROCEDURE mostrarSubastasCompradorNot(ali IN varchar, contra IN varchar, cursor OUT SYS_REFCURSOR)
IS

    compId integer;

BEGIN

    SELECT comprador.ID INTO compId
    FROM comprador
    INNER JOIN participante ON comprador.participanteid = participante.ID
    INNER JOIN usuario ON participante.usuarioid = usuario.ID
    AND usuario.alias = ali AND usuario.contrasenna = contra;

    OPEN CURSOR FOR SELECT item.nombre, item.descripcion, item.imagen, subasta.detallesentrega
	FROM subasta 
	INNER JOIN item ON item.ID = subasta.itemid
	INNER JOIN puja ON puja.monto = subasta.montoactual AND puja.subastaid = subasta.ID
	INNER JOIN comprador ON puja.compradorid = comprador.ID AND comprador.ID = compId
	WHERE subasta.activo = 0;

END;
/

