create PROCEDURE mostrarSubastasVendedorNot(ali IN varchar, contra IN varchar, cursor OUT SYS_REFCURSOR)
IS

    vendid integer;

BEGIN

    SELECT vendedor.ID INTO vendid
    FROM vendedor
    INNER JOIN participante ON vendedor.participanteid = participante.ID
    INNER JOIN usuario ON participante.usuarioid = usuario.ID
    AND usuario.alias = ali AND usuario.contrasenna = contra;

    OPEN CURSOR FOR SELECT item.nombre, item.descripcion, item.imagen, subasta.detallesentrega
	FROM subasta 
	INNER JOIN item ON item.ID = subasta.itemid
	INNER JOIN vendedor ON subasta.vendedorid = vendedor.id AND vendedor.id = vendid
	WHERE subasta.activo = 0;

END;
/

