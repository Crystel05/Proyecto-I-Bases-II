create PROCEDURE enviarComentario(coment varchar, puntu int, esVend int, compra int, 
												   itemNom varchar, ali varchar, contra varchar, cursor OUT SYS_REFCURSOR)
IS

    compid int;
    subasId int;
	vendid int;
	partId int;
	montoMax int;
    resultado int := 0;

BEGIN

    SELECT participante.ID INTO partId 
    FROM participante 
    INNER JOIN usuario ON participante.usuarioid = usuario.ID
    AND usuario.alias = ali AND usuario.contrasenna = contra;

    SELECT subasta.ID INTO subasId
    FROM subasta
    INNER JOIN item ON item.ID = subasta.itemid AND item.nombre = itemNom;

    SELECT max(monto) INTO montoMax
    FROM puja WHERE subastaid = subasId;

    IF esVend = 1 
	THEN

        SELECT vendedor.ID INTO vendId
        FROM vendedor 
        INNER JOIN participante ON vendedor.participanteId = participante.ID AND participante.ID = partId;

		SELECT comprador.ID INTO compid
        FROM comprador
        INNER JOIN puja ON comprador.ID = puja.compradorId
        INNER JOIN subasta ON puja.subastaId = subasta.ID
        AND subasta.ID = subasId AND puja.monto = montoMax;	  

	ELSE

        SELECT vendedorid INTO vendId
        FROM subasta 
        WHERE ID = subasId;

        SELECT comprador.ID INTO compId
        FROM comprador
        INNER JOIN participante ON comprador.participanteid = participante.ID AND participante.ID = partId;

	END IF;

    SELECT COUNT(*) INTO resultado 
    FROM comentario 
    WHERE subastaid = subasId AND esVendedor = esVend;

    IF  resultado > 0
	THEN

		UPDATE comentario
		SET comentario = coment, puntaje = puntu
		WHERE ID = (SELECT ID FROM comentario WHERE subastaid = subasId AND esvendedor = esVend);

	ELSE
		INSERT INTO comentario(comentario, puntaje, compradorid, vendedorid, subastaid, esvendedor)
		VALUES (coment, puntu, compid, vendid, subasId, esVend);

		IF esVend = 0
		THEN 

			INSERT INTO historialcomprador(subastaid, compradorId, compra)
			VALUES (subasId, compid, compra);

		END IF;
	END IF;

END;
/

