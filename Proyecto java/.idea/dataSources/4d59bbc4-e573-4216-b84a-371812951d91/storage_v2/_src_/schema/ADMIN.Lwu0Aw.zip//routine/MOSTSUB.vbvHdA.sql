create PROCEDURE mostSub(cursor OUT SYS_REFCURSOR)
IS

BEGIN

    OPEN cursor FOR
	SELECT subasta.ID, 
    item.nombre, 
    subasta.fechafinal, 
    subasta.montoActual, 
    subasta.precioinicial, 
    item.descripcion, 
    item.imagen 
	FROM subasta
	INNER JOIN item on subasta.itemid = item."ID"
	WHERE subasta.activo = 1;

END;
/

