create type         "SYS_YOID0000074925$"              as object( "CODIGO" VARCHAR2(10 BYTE))
/

