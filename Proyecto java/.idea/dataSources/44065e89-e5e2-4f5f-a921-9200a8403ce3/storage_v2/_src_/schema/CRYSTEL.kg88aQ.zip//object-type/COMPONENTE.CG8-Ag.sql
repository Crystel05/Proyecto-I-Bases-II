create TYPE Componente UNDER Parte(
    
    partesComponente partes,
    cantidadesComponente cantidades,
    MEMBER FUNCTION cantidadTotalOriginales RETURN INTEGER,
    MEMBER FUNCTION cantidadPartesBasicas RETURN INTEGER 
    
)NOT FINAL;
/

