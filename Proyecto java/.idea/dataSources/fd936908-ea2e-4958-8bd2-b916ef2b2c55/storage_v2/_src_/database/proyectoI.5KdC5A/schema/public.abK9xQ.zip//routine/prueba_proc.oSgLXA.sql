create procedure prueba_proc(a character varying, INOUT c character varying)
    language plpgsql
as
$$
DECLARE
BEGIN
c := a;
END;
$$;

alter procedure prueba_proc(varchar, inout varchar) owner to postgres;

