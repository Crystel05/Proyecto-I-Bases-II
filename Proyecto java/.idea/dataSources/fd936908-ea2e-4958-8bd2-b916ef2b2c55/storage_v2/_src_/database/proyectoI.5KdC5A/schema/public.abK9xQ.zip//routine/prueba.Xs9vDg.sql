create function prueba(a integer) returns integer
    language sql
as
$$
SELECT a;

$$;

alter function prueba(integer) owner to postgres;

